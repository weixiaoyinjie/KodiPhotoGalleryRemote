package com.example.kodiphotoremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** PHOTO / KODI v1.0 — separate Kodi JSON-RPC remote for NAS/SMB pictures. */
public final class MainActivity extends Activity {
    private static final int BG=0xFF080F1D, PANEL=0xFF172338, CARD=0xFF1B2A41, BORDER=0xFF354560;
    private static final int TEAL=0xFF43DECF, TEXT=0xFFF5F8FF, SECOND=0xFFADC0D5;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final ExecutorService thumbs=Executors.newFixedThreadPool(3);
    private final LruCache<String,Bitmap> memory=new LruCache<String,Bitmap>(18*1024*1024){
        @Override protected int sizeOf(String k,Bitmap b){return b.getByteCount();}
    };
    private EditText ipInput,portInput,userInput,passwordInput,filterInput;
    private TextView status,folderLabel,countLabel,viewButton,sortButton,playingName,playPauseButton,sourceButton,slideButton;
    private LinearLayout connectionForm,hero;
    private GridView gallery;
    private ProgressBar progress;
    private GalleryAdapter adapter;
    private final ArrayList<Photo> entries=new ArrayList<>(),displayed=new ArrayList<>(),sources=new ArrayList<>();
    private final ArrayList<String> history=new ArrayList<>();
    private String host="",port="8080",user="",pass="",folder="";
    private volatile boolean connected=false;
    private boolean settingsVisible=true,listMode=false,sortNewest=false,picturePlaying=false,paused=false,manualSingle=false;
    private int loadSerial=0, imageSerial=0,playerId=2;
    private String currentImage="";

    private static final class Photo {
        final String path,title,thumb;
        final boolean directory;
        Photo(String p,String t,String th,boolean d){path=p;title=t;thumb=th;directory=d;}
    }
    private interface Work {void execute() throws Exception;}
    private int dp(float x){return Math.round(x*getResources().getDisplayMetrics().density);}
    private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private GradientDrawable bg(int c,int radius){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable edge(int c,int radius){GradientDrawable d=bg(c,radius);d.setStroke(dp(1),BORDER);return d;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private TextView button(String s,boolean accent,View.OnClickListener click){TextView t=text(s,13,accent?BG:TEXT,true);t.setGravity(Gravity.CENTER);t.setBackground(accent?bg(TEAL,14):edge(PANEL,14));t.setOnClickListener(click);t.setPadding(dp(5),dp(1),dp(5),dp(1));return t;}
    private EditText field(String hint,boolean secret){EditText t=new EditText(this);t.setTextColor(TEXT);t.setHintTextColor(SECOND);t.setTextSize(13);t.setSingleLine(true);t.setHint(hint);t.setBackground(edge(CARD,12));t.setPadding(dp(10),0,dp(10),0);if(secret)t.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return t;}
    private void addWeight(LinearLayout p,View v,int h,float weight){p.addView(v,new LinearLayout.LayoutParams(0,dp(h),weight));}
    private void gap(LinearLayout p,int pixels){p.addView(new View(this),lp(1,pixels));}
    private JSONObject o(String k,Object v){JSONObject x=new JSONObject();try{x.put(k,v);}catch(Exception ignored){}return x;}
    private JSONArray array(String... v){JSONArray a=new JSONArray();for(String s:v)a.put(s);return a;}
    private void run(Work job){io.execute(()->{try{job.execute();}catch(Exception e){error(e);}});}
    private void error(Exception e){String s=e.getMessage()!=null?e.getMessage():e.toString();ui.post(()->{progress.setVisibility(View.GONE);status.setText("● "+s);Toast.makeText(this,s,Toast.LENGTH_LONG).show();});}
    private void note(String t){ui.post(()->Toast.makeText(this,t,Toast.LENGTH_SHORT).show());}

    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);build();
        ipInput.setText(getPreferences(MODE_PRIVATE).getString("host","192.168.0.55"));
        portInput.setText(getPreferences(MODE_PRIVATE).getString("port","8080"));
        userInput.setText(getPreferences(MODE_PRIVATE).getString("user","kodi"));
        listMode=getPreferences(MODE_PRIVATE).getBoolean("list",false);
        sortNewest=getPreferences(MODE_PRIVATE).getBoolean("newest",false);
        updateToggles();
        ui.postDelayed(poll,3000);
    }
    private void build(){
        LinearLayout root=column();root.setPadding(dp(14),dp(11),dp(14),dp(5));root.setBackgroundColor(BG);setContentView(root);
        LinearLayout top=row();LinearLayout branding=column();
        TextView title=text("PHOTO  /  KODI",23,TEXT,true);branding.addView(title,lp(-1,35));
        status=text("● 未连接 · 用手机控制电视照片",11,SECOND,false);status.setSingleLine(true);status.setEllipsize(TextUtils.TruncateAt.END);branding.addView(status,lp(-1,22));
        top.addView(branding,new LinearLayout.LayoutParams(0,dp(60),1));
        top.addView(button("⚙  连接",false,v->{settingsVisible=!settingsVisible;connectionForm.setVisibility(settingsVisible?View.VISIBLE:View.GONE);}),lp(90,41));
        root.addView(top,lp(-1,64));gap(root,5);
        connectionForm=column();connectionForm.setBackground(edge(PANEL,17));connectionForm.setPadding(dp(10),dp(10),dp(10),dp(11));
        LinearLayout hostRow=row();ipInput=field("Google TV / Kodi IP",false);portInput=field("端口",false);portInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        addWeight(hostRow,ipInput,44,3);hostRow.addView(new View(this),lp(7,1));addWeight(hostRow,portInput,44,1);connectionForm.addView(hostRow);
        gap(connectionForm,7);
        LinearLayout auth=row();userInput=field("Kodi 用户名",false);passwordInput=field("Kodi 密码（不保存）",true);
        addWeight(auth,userInput,43,1);auth.addView(new View(this),lp(7,1));addWeight(auth,passwordInput,43,1.7f);connectionForm.addView(auth);gap(connectionForm,7);
        connectionForm.addView(button("连接 Kodi · 读取照片源  →",true,v->connect()),lp(-1,45));root.addView(connectionForm);
        gap(root,9);
        hero=column();hero.setBackground(edge(PANEL,17));hero.setPadding(dp(13),dp(10),dp(13),dp(10));
        TextView small=text("✦  YOUR PRIVATE PHOTO LIBRARY",10,TEAL,true);hero.addView(small,lp(-1,20));
        TextView big=text("私人相册 · 电视幻灯片",20,TEXT,true);hero.addView(big,lp(-1,35));
        TextView subtitle=text("SMB 硬盘由 Kodi 直接读取 · 手机只负责选择和控制",11,SECOND,false);subtitle.setMaxLines(2);hero.addView(subtitle,lp(-1,36));
        LinearLayout actions=row();sourceButton=button("☷ 图片来源",false,v->chooseSource());
        addWeight(actions,sourceButton,42,1.1f);actions.addView(new View(this),lp(7,1));
        actions.addView(button("＋ 指定 SMB 目录",false,v->customPath()),new LinearLayout.LayoutParams(0,dp(42),1.4f));
        hero.addView(actions);root.addView(hero);gap(root,9);
        LinearLayout tools=row();TextView prev=button("‹ 返回",false,v->backFolder());tools.addView(prev,lp(73,40));tools.addView(new View(this),lp(6,1));
        countLabel=text("照片文件夹",15,TEXT,true);tools.addView(countLabel,new LinearLayout.LayoutParams(0,dp(40),1));
        viewButton=button("☷ 列表",false,v->switchView());tools.addView(viewButton,lp(75,40));tools.addView(new View(this),lp(5,1));
        sortButton=button("A-Z",false,v->toggleSort());tools.addView(sortButton,lp(56,40));root.addView(tools);
        folderLabel=text("选择图片源，或输入 Kodi 已能访问的 SMB 文件夹",11,SECOND,false);folderLabel.setSingleLine(true);folderLabel.setEllipsize(TextUtils.TruncateAt.MIDDLE);root.addView(folderLabel,lp(-1,26));
        filterInput=field("搜索当前文件夹照片 / 名称",false);root.addView(filterInput,lp(-1,41));
        filterInput.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int c,int a){}public void onTextChanged(CharSequence s,int start,int before,int count){refresh();}public void afterTextChanged(Editable e){}});
        gallery=new GridView(this);gallery.setNumColumns(3);gallery.setHorizontalSpacing(dp(8));gallery.setVerticalSpacing(dp(9));gallery.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);gallery.setClipToPadding(false);
        gallery.setPadding(0,dp(10),0,dp(10));gallery.setSelector(android.R.color.transparent);adapter=new GalleryAdapter();gallery.setAdapter(adapter);
        gallery.setOnItemClickListener((parent,v,pos,id)->{if(pos>=displayed.size())return;Photo item=displayed.get(pos);if(item.directory){history.add(folder);openFolder(item.path);}else openPicture(item);});
        gallery.setOnItemLongClickListener((parent,v,pos,id)->{if(pos>=displayed.size())return false;Photo item=displayed.get(pos);if(item.directory){new AlertDialog.Builder(this).setTitle(item.title).setItems(new String[]{"打开文件夹","按顺序播放此文件夹","随机幻灯片"},(d,which)->{if(which==0){history.add(folder);openFolder(item.path);}else slideshow(item.path,which==2);}).show();}else{new AlertDialog.Builder(this).setTitle(item.title).setItems(new String[]{"在电视显示","手机预览","播放所在文件夹幻灯片"},(d,which)->{if(which==0)openPicture(item);if(which==1)preview(item);if(which==2)slideshow(folder,false);}).show();}return true;});
        root.addView(gallery,new LinearLayout.LayoutParams(-1,0,1));
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setIndeterminate(true);progress.setVisibility(View.GONE);root.addView(progress,lp(-1,3));
        LinearLayout bottom=column();bottom.setBackground(edge(PANEL,17));bottom.setPadding(dp(10),dp(9),dp(10),dp(10));
        LinearLayout caption=row();playingName=text("● 等待在电视上显示照片",12,TEXT,true);playingName.setSingleLine(true);playingName.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        caption.addView(playingName,new LinearLayout.LayoutParams(0,dp(29),1));TextView settings=button("设置提示",false,v->showHelp());caption.addView(settings,lp(75,31));bottom.addView(caption);gap(bottom,6);
        LinearLayout bigControls=row();TextView previous=button("⏮  上一张",false,v->changePicture(false));previous.setTextSize(15);addWeight(bigControls,previous,57,1);
        bigControls.addView(new View(this),lp(6,1));playPauseButton=button("⏸ 暂停",true,v->pause());playPauseButton.setTextSize(15);addWeight(bigControls,playPauseButton,57,1);
        bigControls.addView(new View(this),lp(6,1));TextView next=button("下一张  ⏭",false,v->changePicture(true));next.setTextSize(15);addWeight(bigControls,next,57,1);bottom.addView(bigControls);gap(bottom,7);
        LinearLayout slides=row();slideButton=button("▶ 文件夹幻灯片",true,v->slideshow(folder,false));addWeight(slides,slideButton,45,1.4f);
        slides.addView(new View(this),lp(7,1));addWeight(slides,button("⇄ 随机播放",false,v->slideshow(folder,true)),45,1);
        slides.addView(new View(this),lp(7,1));addWeight(slides,button("■ 停止",false,v->stop()),45,.7f);bottom.addView(slides);gap(bottom,7);
        LinearLayout ex=row();addWeight(ex,button("↻ 旋转",false,v->pictureAction("Player.Rotate",o("value","clockwise"))),40,1);
        ex.addView(new View(this),lp(6,1));addWeight(ex,button("＋ 放大",false,v->pictureAction("Player.Zoom",o("zoom","in"))),40,1);
        ex.addView(new View(this),lp(6,1));addWeight(ex,button("− 缩小",false,v->pictureAction("Player.Zoom",o("zoom","out"))),40,1);
        bottom.addView(ex);root.addView(bottom);gap(root,5);
        refresh();
    }
    private void updateToggles(){if(viewButton!=null)viewButton.setText(listMode?"▦ 网格":"☷ 列表");if(sortButton!=null)sortButton.setText(sortNewest?"Z-A":"A-Z");if(gallery!=null){gallery.setNumColumns(listMode?1:3);if(adapter!=null)adapter.notifyDataSetChanged();}}
    private void switchView(){listMode=!listMode;getPreferences(MODE_PRIVATE).edit().putBoolean("list",listMode).apply();updateToggles();}
    private void toggleSort(){sortNewest=!sortNewest;getPreferences(MODE_PRIVATE).edit().putBoolean("newest",sortNewest).apply();updateToggles();refresh();}
    private JSONObject rpc(String method,JSONObject params)throws Exception{
        if(host.isEmpty())throw new Exception("请先连接 Kodi");
        HttpURLConnection conn=(HttpURLConnection)new URL("http://"+host+":"+port+"/jsonrpc").openConnection();
        conn.setRequestMethod("POST");conn.setConnectTimeout(5000);conn.setReadTimeout(10000);conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type","application/json; charset=utf-8");
        if(!user.isEmpty()||!pass.isEmpty())conn.setRequestProperty("Authorization","Basic "+Base64.encodeToString((user+":"+pass).getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP));
        JSONObject body=o("jsonrpc","2.0");body.put("id",1);body.put("method",method);if(params!=null)body.put("params",params);
        byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);conn.setFixedLengthStreamingMode(bytes.length);
        try{
            try(OutputStream out=conn.getOutputStream()){out.write(bytes);}
            int code=conn.getResponseCode();if(code==401)throw new Exception("Kodi 用户名/密码不正确 (401)");if(code!=200)throw new Exception("Kodi HTTP 错误 "+code);
            ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=conn.getInputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>4*1024*1024)throw new Exception("文件夹太大，请缩小目录");}}
            JSONObject data=new JSONObject(out.toString("UTF-8"));
            if(data.has("error"))throw new Exception(method+": "+data.getJSONObject("error").optString("message","执行失败"));return data;
        }finally{conn.disconnect();}
    }
    private void connect(){String h=ipInput.getText().toString().trim();String p=portInput.getText().toString().trim();
        if(!h.matches("[A-Za-z0-9.\\-]+")||h.isEmpty()){note("请输入正确的 Kodi 局域网地址");return;}
        if(!p.matches("[0-9]{1,5}")||Integer.parseInt(p)<1||Integer.parseInt(p)>65535){note("端口必须在 1–65535 之间");return;}
        host=h;port=p;user=userInput.getText().toString().trim();pass=passwordInput.getText().toString();connected=false;
        getPreferences(MODE_PRIVATE).edit().putString("host",host).putString("port",port).putString("user",user).apply();
        status.setText("● 正在连接 Kodi...");progress.setVisibility(View.VISIBLE);
        run(()->{rpc("JSONRPC.Ping",new JSONObject());connected=true;
            ui.post(()->{status.setText("● 已连接 · "+host+":"+port);connectionForm.setVisibility(View.GONE);settingsVisible=false;progress.setVisibility(View.GONE);});
            loadSources();
        });
    }
    private void loadSources()throws Exception{
        ArrayList<Photo> list=new ArrayList<>();
        for(String media:new String[]{"pictures","video"}){
            try{
                JSONObject j=rpc("Files.GetSources",o("media",media)).optJSONObject("result");JSONArray items=j==null?null:j.optJSONArray("sources");
                if(items!=null)for(int i=0;i<items.length();i++){
                    JSONObject x=items.optJSONObject(i);if(x==null)continue;
                    String path=x.optString("file","");if(path.isEmpty())continue;
                    boolean duplicate=false;for(Photo p:list)if(p.path.equals(path))duplicate=true;
                    if(!duplicate)list.add(new Photo(path,x.optString("label",path),"",true));
                }
            }catch(Exception ignored){}
        }
        String manual=getPreferences(MODE_PRIVATE).getString("manual_path","");
        if(!manual.isEmpty()){boolean duplicate=false;for(Photo p:list)if(p.path.equals(manual))duplicate=true;if(!duplicate)list.add(new Photo(manual,"我的 SMB 图片库","",true));}
        sources.clear();sources.addAll(list);
        if(sources.isEmpty()){
            ui.post(()->{status.setText("● 已连接 · 尚未添加图片源");note("请在 Kodi 添加图片源，或指定已有 SMB 目录");});
        }else{
            String previous=getPreferences(MODE_PRIVATE).getString("last_path","");
            if(!previous.isEmpty()){
                try{openFolderNow(previous);return;}catch(Exception ignored){}
            }
            showSources();
        }
    }
    private void chooseSource(){if(!connected){note("先连接 Kodi");return;}
        if(sources.isEmpty()){customPath();return;}
        String[] names=new String[sources.size()+1];for(int i=0;i<sources.size();i++)names[i]=sources.get(i).title;names[names.length-1]="＋ 手动输入 SMB 目录";
        new AlertDialog.Builder(this).setTitle("选择照片来源").setItems(names,(d,which)->{
            if(which==sources.size()){customPath();return;}
            history.clear();openFolder(sources.get(which).path);
        }).setNegativeButton("关闭",null).show();
    }
    private void showSources(){ui.post(()->{folder="";history.clear();entries.clear();entries.addAll(sources);filterInput.setText("");refresh();folderLabel.setText("选择照片源 · 点击打开文件夹");});}
    private void customPath(){EditText edit=field("smb://192.168.0.121/airdisk/Photos/",false);
        String old=getPreferences(MODE_PRIVATE).getString("manual_path","");edit.setText(old);
        LinearLayout box=column();box.setPadding(dp(20),dp(8),dp(20),0);box.addView(edit,lp(-1,50));
        new AlertDialog.Builder(this).setTitle("指定 Kodi 可访问的照片目录").setMessage("请使用 Kodi 已添加或可访问的完整目录，例如 smb://192.168.0.121/airdisk/Photos/ 。照片仍由电视 Kodi 直接读取。")
            .setView(box).setNegativeButton("取消",null).setPositiveButton("保存并打开",(d,w)->{
                String p=edit.getText().toString().trim();if(!(p.startsWith("smb://")||p.startsWith("nfs://")||p.startsWith("special://"))||!p.endsWith("/")){note("请填写以 / 结尾的 SMB / NFS 路径");return;}
                getPreferences(MODE_PRIVATE).edit().putString("manual_path",p).apply();
                boolean exists=false;for(Photo source:sources)if(source.path.equals(p))exists=true;
                if(!exists)sources.add(new Photo(p,"自定义照片目录","",true));history.clear();openFolder(p);
            }).show();
    }
    private void openFolder(String path){if(!connected){note("先连接 Kodi");return;}progress.setVisibility(View.VISIBLE);int serial=++loadSerial;
        run(()->{try{loadDirectory(path,serial);}catch(Exception e){error(e);}});
    }
    private void openFolderNow(String path)throws Exception{loadDirectory(path,++loadSerial);}
    private void loadDirectory(String path,int serial)throws Exception{
        JSONArray files=null;Exception cause=null;
        for(String media:new String[]{"pictures","files"}){
            JSONObject q=o("directory",path);
            try{
                q.put("media",media);q.put("properties",array("thumbnail"));
                JSONObject result=rpc("Files.GetDirectory",q).optJSONObject("result");files=result==null?null:result.optJSONArray("files");
                if(files!=null)break;
            }catch(Exception e){cause=e;}
        }
        if(files==null){if(cause!=null)throw cause;throw new Exception("Kodi 没有返回文件，请确认源路径有效");}
        final ArrayList<Photo> next=new ArrayList<>();
        for(int i=0;i<files.length();i++){
            JSONObject x=files.optJSONObject(i);if(x==null)continue;
            String pathName=x.optString("file","");String label=x.optString("label",nameOf(pathName));
            if(pathName.isEmpty())continue;
            boolean folder="directory".equalsIgnoreCase(x.optString("filetype",""));
            if(!folder&&!isPicture(pathName))continue;
            next.add(new Photo(pathName,label,x.optString("thumbnail",""),folder));
        }
        ui.post(()->{
            if(serial!=loadSerial)return;folder=path;getPreferences(MODE_PRIVATE).edit().putString("last_path",path).apply();
            entries.clear();entries.addAll(next);filterInput.setText("");refresh();
            folderLabel.setText(path);progress.setVisibility(View.GONE);
            if(next.isEmpty())note("文件夹为空，或图片格式不受支持");
        });
    }
    private boolean isPicture(String path){String p=path.toLowerCase(Locale.ROOT);int dot=p.lastIndexOf('.');if(dot<0)return false;
        String x=p.substring(dot);return x.equals(".jpg")||x.equals(".jpeg")||x.equals(".png")||x.equals(".webp")||x.equals(".bmp")||x.equals(".gif")||x.equals(".tif")||x.equals(".tiff")||x.equals(".heic")||x.equals(".heif");
    }
    private String nameOf(String p){if(p==null||p.isEmpty())return "未命名";String trim=p.endsWith("/")?p.substring(0,p.length()-1):p;int k=trim.lastIndexOf('/');return trim.substring(k+1);}
    private void backFolder(){if(!connected)return;if(!history.isEmpty()){openFolder(history.remove(history.size()-1));return;}showSources();}
    @Override public void onBackPressed(){if(connected&&!folder.isEmpty())backFolder();else super.onBackPressed();}
    private void refresh(){if(gallery==null)return;
        String keyword=filterInput==null?"":filterInput.getText().toString().trim().toLowerCase(Locale.ROOT);
        displayed.clear();for(Photo p:entries)if(keyword.isEmpty()||p.title.toLowerCase(Locale.ROOT).contains(keyword))displayed.add(p);
        Collections.sort(displayed,(a,b)->{if(a.directory!=b.directory)return a.directory?-1:1;return sortNewest?b.title.compareToIgnoreCase(a.title):a.title.compareToIgnoreCase(b.title);});
        int photos=0,folders=0;for(Photo p:displayed){if(p.directory)folders++;else photos++;}
        if(countLabel!=null)countLabel.setText(String.format(Locale.ROOT,"相册 · %d 图 %d 文件夹",photos,folders));
        adapter.notifyDataSetChanged();
    }
    private void openPicture(Photo p){if(!connected){note("请先连接 Kodi");return;}
        run(()->{
            rpc("Player.Open",o("item",o("file",p.path)));
            picturePlaying=true;paused=false;manualSingle=true;currentImage=p.path;
            ui.post(()->{playingName.setText("● 电视显示 · "+p.title);playPauseButton.setText("⏸ 暂停");status.setText("● 已发送图片到 Google TV");});
        });
    }
    private void slideshow(String path,boolean random){if(!connected){note("先连接 Kodi");return;}
        if(path==null||path.isEmpty()){note("请先进入照片文件夹");return;}
        run(()->{
            JSONObject item=o("path",path);item.put("random",random);item.put("recursive",false);
            JSONObject params=o("item",item);params.put("options",o("shuffled",random));
            rpc("Player.Open",params);picturePlaying=true;paused=false;manualSingle=false;currentImage="";
            ui.post(()->{playingName.setText(random?"● 随机幻灯片 · 正在播放":"● 顺序幻灯片 · 正在播放");playPauseButton.setText("⏸ 暂停");status.setText("● 电视正在播放照片幻灯片");});
        });
    }
    private void changePicture(boolean next){if(!connected){note("先连接 Kodi");return;}
        // An individual Player.Open({file:...}) does not create a Kodi slideshow playlist.
        // Navigate manually through the currently opened folder to avoid the old video-remote skip bug.
        if(manualSingle&&!currentImage.isEmpty()){
            ArrayList<Photo> pictures=new ArrayList<>();for(Photo p:displayed)if(!p.directory)pictures.add(p);
            int position=-1;for(int i=0;i<pictures.size();i++)if(pictures.get(i).path.equals(currentImage)){position=i;break;}
            if(position>=0&&pictures.size()>1){
                Photo photo=pictures.get((position+(next?1:pictures.size()-1))%pictures.size());openPicture(photo);return;
            }
        }
        run(()->{
            try{rpc("Player.GoTo",oPlayer("to",next?"next":"previous"));}
            catch(Exception ex){rpc("Player.Move",oPlayer("direction",next?"right":"left"));}
            note(next?"下一张":"上一张");
        });
    }
    private JSONObject oPlayer(String k,Object v){JSONObject p=o("playerid",playerId);try{p.put(k,v);}catch(Exception ignored){}return p;}
    private void pause(){if(!connected){note("先连接 Kodi");return;}
        run(()->{rpc("Player.PlayPause",oPlayer("play","toggle"));paused=!paused;ui.post(()->playPauseButton.setText(paused?"▶ 继续":"⏸ 暂停"));});
    }
    private void stop(){if(!connected)return;
        run(()->{rpc("Player.Stop",oPlayer("playerid",playerId));picturePlaying=false;manualSingle=false;
            ui.post(()->{playingName.setText("● 照片已停止");playPauseButton.setText("▶ 继续");});});
    }
    private void pictureAction(String method,JSONObject args){if(!connected)return;
        run(()->{args.put("playerid",playerId);rpc(method,args);});
    }
    private final Runnable poll=new Runnable(){@Override public void run(){if(connected){io.execute(()->{try{
        JSONObject resp=rpc("Player.GetActivePlayers",new JSONObject());JSONArray active=resp.optJSONArray("result");boolean hasPictures=false;
        if(active!=null)for(int i=0;i<active.length();i++){
            JSONObject player=active.optJSONObject(i);if(player!=null&&"picture".equalsIgnoreCase(player.optString("type"))){playerId=player.optInt("playerid",2);hasPictures=true;break;}
        }
        if(hasPictures){
            JSONObject item=rpc("Player.GetItem",oPlayer("properties",array("file","title"))).optJSONObject("result");
            JSONObject picture=item==null?null:item.optJSONObject("item");String label=picture==null?"":picture.optString("label","");
            picturePlaying=true;
            ui.post(()->{if(!label.isEmpty())playingName.setText("● 正在显示 · "+label);});
        }else if(picturePlaying){picturePlaying=false;manualSingle=false;ui.post(()->playingName.setText("● Kodi 未在播放照片"));}
    }catch(Exception ignored){} });}ui.postDelayed(this,4000);}};
    private void showHelp(){new AlertDialog.Builder(this).setTitle("幻灯片与 Kodi 设置")
        .setMessage("1. 先在 Google TV 的 Kodi：设置 → 服务 → 控制 → 允许通过 HTTP 远程控制。\n\n"+
            "2. Kodi：图片 → 添加图片源，添加 SMB 共享。手机可读取图片源；也可在 App 手动填写 Kodi 可访问的 SMB 目录。\n\n"+
            "3. 进入图片文件夹后点击【文件夹幻灯片】。默认只播放当前文件夹，不扫描子文件夹。\n\n"+
            "4. 图片切换秒数与缩放动画由电视 Kodi 设置：设置 → 播放器 → 图片。\n\n"+
            "5. 缩微图由 Kodi HTTP 图片接口提供。部分照片格式或旧 Kodi 可能无法显示缩略图。\n\n"+
            "6. Kodi 网页控制通常在可信局域网用 HTTP；避免把 Kodi 的 8080 端口暴露到互联网。")
        .setPositiveButton("知道了",null).show();}
    private String enc(String path){try{return URLEncoder.encode(path,"UTF-8").replace("+","%20");}catch(Exception e){return path;}}
    private String auth(){return "Basic "+Base64.encodeToString((user+":"+pass).getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);}
    private File cachedFile(String key){try{MessageDigest dig=MessageDigest.getInstance("SHA-256");byte[] b=dig.digest(key.getBytes(StandardCharsets.UTF_8));StringBuilder str=new StringBuilder();for(int i=0;i<15;i++)str.append(String.format(Locale.ROOT,"%02x",b[i]&255));File dir=new File(getCacheDir(),"photo-thumbs");if(!dir.exists())dir.mkdirs();return new File(dir,str.toString()+".jpg");}catch(Exception e){return null;}}
    private void thumbnail(ImageView target,Photo photo){if(photo.directory){target.setImageDrawable(null);target.setBackground(bg(CARD,12));return;}
        String key=host+":"+port+"|"+photo.path;target.setTag(key);Bitmap inMemory=memory.get(key);
        if(inMemory!=null){target.setImageBitmap(inMemory);return;}target.setImageDrawable(null);target.setBackground(bg(CARD,12));
        thumbs.execute(()->{
            Bitmap loaded=null;File cache=cachedFile(key);
            if(cache!=null&&cache.isFile()){loaded=BitmapFactory.decodeFile(cache.getAbsolutePath());}
            if(loaded==null){
                ArrayList<String> variants=new ArrayList<>();
                if(!photo.thumb.isEmpty())variants.add(photo.thumb);
                variants.add(photo.path);
                variants.add("image://"+enc(photo.path)+"/");
                for(String candidate:variants){loaded=downloadBitmap("http://"+host+":"+port+"/image/"+enc(candidate));if(loaded!=null)break;}
                if(loaded==null&&(photo.path.toLowerCase(Locale.ROOT).endsWith(".jpg")||photo.path.toLowerCase(Locale.ROOT).endsWith(".jpeg")||photo.path.toLowerCase(Locale.ROOT).endsWith(".png"))){
                    loaded=downloadBitmap("http://"+host+":"+port+"/vfs/"+enc(photo.path));
                }
                if(loaded!=null&&cache!=null)saveBitmap(cache,loaded);
            }
            if(loaded!=null){memory.put(key,loaded);Bitmap result=loaded;ui.post(()->{if(key.equals(target.getTag()))target.setImageBitmap(result);});}
        });
    }
    private Bitmap downloadBitmap(String url){HttpURLConnection c=null;try{
        c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(3500);c.setReadTimeout(7000);if(!user.isEmpty()||!pass.isEmpty())c.setRequestProperty("Authorization",auth());
        if(c.getResponseCode()!=200)return null;
        ByteArrayOutputStream sink=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){
            byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1){sink.write(b,0,n);if(sink.size()>10*1024*1024)return null;}}
        byte[] data=sink.toByteArray();BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(data,0,data.length,opts);
        opts.inJustDecodeBounds=false;int sample=1;while(opts.outWidth/sample>850||opts.outHeight/sample>850)sample*=2;opts.inSampleSize=sample;
        return BitmapFactory.decodeByteArray(data,0,data.length,opts);
    }catch(Exception ignored){return null;}finally{if(c!=null)c.disconnect();}}
    private void saveBitmap(File file,Bitmap bitmap){try(FileOutputStream out=new FileOutputStream(file)){bitmap.compress(Bitmap.CompressFormat.JPEG,80,out);}catch(Exception ignored){} }
    private void preview(Photo p){ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setBackgroundColor(BG);image.setAdjustViewBounds(true);image.setMinimumHeight(dp(220));thumbnail(image,p);
        LinearLayout container=column();container.setPadding(dp(12),dp(4),dp(12),dp(4));container.addView(image,lp(-1,-2));
        new AlertDialog.Builder(this).setTitle(p.title).setView(container).setNegativeButton("关闭",null).setPositiveButton("在电视显示",(d,w)->openPicture(p)).show();}
    private final class GalleryAdapter extends BaseAdapter {
        @Override public int getCount(){return displayed.size();}
        @Override public Object getItem(int i){return displayed.get(i);}
        @Override public long getItemId(int i){return i;}
        @Override public View getView(int pos,View convert,ViewGroup parent){
            Photo item=displayed.get(pos);LinearLayout box=column();box.setBackground(edge(PANEL,14));box.setPadding(dp(6),dp(6),dp(6),dp(8));
            if(listMode){LinearLayout line=row();ImageView img=new ImageView(MainActivity.this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                img.setBackground(bg(CARD,10));line.addView(img,lp(110,77));if(item.directory){img.setImageDrawable(null);img.setImageResource(android.R.drawable.ic_menu_gallery);img.setColorFilter(TEAL);}
                else thumbnail(img,item);
                LinearLayout caption=column();caption.setPadding(dp(12),0,dp(4),0);TextView name=text(item.title,14,TEXT,true);name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);caption.addView(name,lp(-1,53));
                caption.addView(text(item.directory?"文件夹 · 点击进入":"照片 · 点击在电视显示",11,SECOND,false),lp(-1,19));line.addView(caption,new LinearLayout.LayoutParams(0,dp(77),1));box.addView(line);return box;}
            ImageView image=new ImageView(MainActivity.this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackground(bg(CARD,10));box.addView(image,lp(-1,110));
            if(item.directory){image.setImageResource(android.R.drawable.ic_menu_gallery);image.setColorFilter(TEAL);image.setPadding(dp(22),dp(22),dp(22),dp(22));}
            else thumbnail(image,item);
            TextView caption=text(item.title,11,TEXT,true);caption.setSingleLine(true);caption.setEllipsize(TextUtils.TruncateAt.END);caption.setPadding(dp(3),dp(6),dp(3),0);box.addView(caption,lp(-1,30));
            return box;
        }
    }
    @Override protected void onDestroy(){ui.removeCallbacks(poll);io.shutdownNow();thumbs.shutdownNow();super.onDestroy();}
}
