# PHOTO / KODI — 私人照片影院 v1.0

专门为 Fold6 + Google TV Kodi + SMB/NAS 图片文件开发的 Android 手机遥控 App。

## 使用方式

1. 在 **Google TV Kodi** 设置 → 服务 → 控制，打开“允许通过 HTTP 进行远程控制”以及“允许其他系统上的应用程序进行远程控制”，确认端口（默认 8080）。
2. 在 Kodi：图片 → 添加图片源，添加包含 JPG、PNG 等照片的 SMB 硬盘文件夹；或者直接使用 Kodi 已添加的 SMB 路径。
3. 在 Fold6 安装 APK，打开 PHOTO / KODI，填 Kodi IP、HTTP 端口和账户。如果没设置密码，密码留空。
4. 点击“连接 Kodi”，App 会读取 Kodi 的图片源，并补充查询 Kodi 的视频源以便复用已有的 SMB 共享。
5. 选目录，点击照片即可让电视 Kodi 显示；点“文件夹幻灯片”启动 Kodi 自带的幻灯片。
6. 如果图片源没有出现，点“指定 SMB 目录”填入完整路径，例如 `smb://192.168.0.121/airdisk/Photos/`，目录必须可由电视 Kodi 打开。
7. 图片切换间隔、随机选项和 Pan & Zoom 动画，由 Kodi 的 设置 → 播放器 → 图片 决定；App 的“顺序/随机”按键会启动相应的幻灯片。

## 功能

- 深色图片库、缩略图网格 / 左图右文列表、按名称搜索、A-Z 与 Z-A、目录返回；
- 手机点开文件 → 电视 Kodi 全屏显示图片；
- 原生 Kodi 图片幻灯片，支持当前文件夹顺序或随机；
- 大按钮：上一张、下一张、暂停/继续、停止、旋转、放大、缩小；
- 不将照片内容通过手机中继传送：Kodi 直接读取 SMB/NFS 文件；
- 缩略图优先使用 Kodi 的 `/image/` URL；必要时尝试 `/vfs/`，并缓存在手机 App 本地。

### 重要限制

- 该 App 需要 Kodi 的 HTTP JSON-RPC 服务，不能只使用电视上的 SMB 或 DLNA 服务作为直接 API；
- 仅展示 Kodi 可访问的文件和支持解码的格式；HEIC/WEBP 等格式是否能显示依赖 Kodi 版本和解码支持；
- 如果 Kodi HTTP 图片接口禁止访问图片，缩略图可能显示占位图，但电视展示功能仍可独立测试；
- 手机的“上一张/下一张”在单张模式直接按当前目录导航，在 Kodi 原生幻灯片模式使用 `Player.GoTo` / `Player.Move`；
- 不能保证 Kodi 内部幻灯片与某些脚本/插件的行为完全一致，需要在你的 Google TV 上联机测试；
- 连接时密码仅保存在运行内存中，不写入手机存储。Kodi HTTP 建议仅在可信局域网开启，不要暴露到公网。

## GitHub Actions 一次上传编译

1. 新建仓库 **KodiPhotoGalleryRemote**，可选 Private。
2. 在仓库根目录直接上传 `KodiPhotoGalleryRemote_v1.0_OneUpload_Source.zip`，**不要解压**。
3. 创建 `.github/workflows/build-apk.yml`，使用本 ZIP 附带的工作流文件（也提供单独 YAML 下载）。
4. 在 GitHub Actions 中点击 `Build PHOTO KODI Android APK` → Run workflow。
5. 从 `PHOTO-KODI-v1.0-debug` Artifacts 下载 APK 安装。该 App 的包名是 `com.example.kodiphotoremote`，和旧版 CINEMA / KODI 完全不同，可同时安装。

## 技术说明

- Java / Android SDK 35，最低 Android 8.0，目标 API 34；
- 使用系统 Android SDK 控件，无第三方 Android 依赖；
- 根据 Kodi 官方文档，`Player.Open({item:{file:...}})` 可播放单文件，`Player.Open({item:{path:...}})` 启动文件夹幻灯片；
- 使用 `Files.GetSources`, `Files.GetDirectory`, `Player.GetActivePlayers`, `Player.GetItem`, `Player.GoTo`, `Player.PlayPause`, `Player.Rotate`, `Player.Zoom`, `Player.Stop`。
- Android 编译和 Google TV 联机尚未完成；部署后应首先验证 HTTP、图片源、点击显示、幻灯片、换图和缩略图。
